
/**
 * Write a description of class AccomplishmentProgram here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class AccomplishmentProgram {
  UI sc = new UI();
  Accomplishment obj[] = new Accomplishment[200];
    
    
  private static final String FILE_NAME= "kaggle-datasets-firsts-TABBED.txt";

} 