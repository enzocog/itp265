
/**
 * Menu Enum
 *
 * @Enzo Coglitore
 * ITP 265 , Ecoglito@usc.edu
 * @version (a version number or a date)
 */
public enum Menu
{
    
}
