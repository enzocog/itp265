/**
 * Brief desription of code: Imported from Kendra
 *
 * @author Kendra Walther
 * ITP 265, Fall 2020. Coffee Section
 * Assignment 08 WEEK 10
 * Email: kwalther@usc.edu
 */
public interface Drawable {

	public void drawInAscii();
}